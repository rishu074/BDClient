package Animal

type Animal struct {
	name string
	topa string
	legs []string
}

func NewAnimal(name string, topa string, legs []string) *Animal {
	return &Animal{
		name: name,
		topa: topa,
		legs: legs,
	}
}

func (a *Animal) GetName() string {
	return a.name
}
