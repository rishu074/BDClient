package main

import (
	"fmt"

	Animal "royadma.dev/structs/structs"
)

func main() {
	karan := Animal.NewAnimal("kuuta bhadwa", "dog", []string{"hello"})
	fmt.Println(karan.GetName())
	fmt.Println(*karan)


}
